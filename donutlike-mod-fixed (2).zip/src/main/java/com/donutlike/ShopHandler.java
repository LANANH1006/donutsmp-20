package com.donutlike;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * /shop kieu DonutSMP cu: Menu chinh (27 o) -> Menu con (54 o) -> Chon so luong (27 o, -64 -10 -1 | item | +1 +10 +64).
 * Chi dung chuot trai. Giao dien ao: moi thao tac click deu bi chan, khong the lay do ra khoi GUI.
 */
public class ShopHandler {

    record Entry(Item item, double price, boolean ench, ItemStack proto, String spec) {
        Entry(Item item, double price) { this(item, price, false, null, null); }
        Entry(Item item, double price, boolean ench) { this(item, price, ench, null, null); }
        Entry(Item item, double price, boolean ench, ItemStack proto) { this(item, price, ench, proto, null); }
        /** Tao n cai (do full phu phep / sach phu phep thi tung cai 1). */
        ItemStack make(int n) {
            if (proto != null) return proto.copy();
            if (spec != null) return Enchants.variant(item, spec);
            if (ench) return Enchants.full(item);
            return new ItemStack(item, n);
        }
    }

    static final Map<String, List<Entry>> CATALOG = new LinkedHashMap<>();
    static final Map<String, String> CAT_TITLE = new LinkedHashMap<>();

    /** Do FULL phu phep, gia = gia /order / sell (Prices.enchUnit). */
    static void addEnch(Item it) { CATALOG.computeIfAbsent("ench", k -> new ArrayList<>()).add(new Entry(it, Prices.enchUnit(it), true)); }

    static void add(String cat, Item it, double price) { CATALOG.computeIfAbsent(cat, k -> new ArrayList<>()).add(new Entry(it, price)); }

    static {
        CAT_TITLE.put("gear", "Gear"); CAT_TITLE.put("nether", "Nether"); CAT_TITLE.put("end", "End"); CAT_TITLE.put("food", "Food"); CAT_TITLE.put("ench", "Enchanted"); CAT_TITLE.put("blocks", "Blocks xây nhà"); CAT_TITLE.put("drops", "Vật phẩm mob & farm"); CAT_TITLE.put("books", "Sách phù phép");
        CAT_TITLE.put("armor", "Giáp (tất cả loại)"); CAT_TITLE.put("templates", "Mẫu rèn (Smithing Template)"); CAT_TITLE.put("tools", "Vũ khí & công cụ"); CAT_TITLE.put("redstone", "Redstone"); CAT_TITLE.put("all", "Tất cả vật phẩm");
        // ----- Gear (hang 1: hoi sinh/ho tro, hang 2: block xay nhanh, hang 3+: vu khi giap) -----
        add("gear", Items.TOTEM_OF_UNDYING, 1000); add("gear", Items.GOLDEN_APPLE, 60); add("gear", Items.ENCHANTED_GOLDEN_APPLE, 5000);
        add("gear", Items.EXPERIENCE_BOTTLE, 30); add("gear", Items.ENDER_PEARL, 40); add("gear", Items.WIND_CHARGE, 60);
        add("gear", Items.FIREWORK_ROCKET, 30); add("gear", Items.ARROW, 2); add("gear", Items.SHIELD, 80);
        add("gear", Items.OBSIDIAN, 15); add("gear", Items.CRYING_OBSIDIAN, 25); add("gear", Items.END_CRYSTAL, 150);
        add("gear", Items.RESPAWN_ANCHOR, 400); add("gear", Items.GLOWSTONE, 20); add("gear", Items.TNT, 50);
        add("gear", Items.COBWEB, 20); add("gear", Items.WATER_BUCKET, 20); add("gear", Items.LAVA_BUCKET, 40);
        add("gear", Items.BOW, 60); add("gear", Items.CROSSBOW, 100);
        add("gear", Items.DIAMOND_SWORD, 450); add("gear", Items.DIAMOND_HELMET, 700); add("gear", Items.DIAMOND_CHESTPLATE, 1100);
        add("gear", Items.DIAMOND_LEGGINGS, 1000); add("gear", Items.DIAMOND_BOOTS, 600);
        add("gear", Items.NETHERITE_SWORD, 3500); add("gear", Items.NETHERITE_HELMET, 3500); add("gear", Items.NETHERITE_CHESTPLATE, 4500);
        add("gear", Items.NETHERITE_LEGGINGS, 4200); add("gear", Items.NETHERITE_BOOTS, 3300);
        add("gear", Items.NETHERITE_PICKAXE, 3500); add("gear", Items.NETHERITE_AXE, 3500); add("gear", Items.MACE, 8000);
        add("gear", Items.ELYTRA, 6000);
        // ----- Enchanted (full phu phep) -----
        // ----- Nether -----
        add("nether", Items.QUARTZ, 8); add("nether", Items.QUARTZ_BLOCK, 32); add("nether", Items.BLAZE_ROD, 40);
        add("nether", Items.NETHER_WART, 12); add("nether", Items.SOUL_SAND, 6); add("nether", Items.MAGMA_BLOCK, 10);
        add("nether", Items.NETHERRACK, 2); add("nether", Items.GLOWSTONE_DUST, 8); add("nether", Items.GHAST_TEAR, 150);
        add("nether", Items.MAGMA_CREAM, 25); add("nether", Items.ANCIENT_DEBRIS, 350); add("nether", Items.NETHERITE_SCRAP, 300);
        add("nether", Items.NETHERITE_INGOT, 1400); add("nether", Items.GOLD_INGOT, 25); add("nether", Items.BASALT, 3);
        add("nether", Items.BLACKSTONE, 3); add("nether", Items.NETHER_BRICKS, 8); add("nether", Items.CRIMSON_STEM, 6);
        add("nether", Items.WARPED_STEM, 6); add("nether", Items.WITHER_SKELETON_SKULL, 5000);
        // ----- End -----
        add("end", Items.SHULKER_BOX, 1500); add("end", Items.SHULKER_SHELL, 600); add("end", Items.ENDER_EYE, 90);
        add("end", Items.ENDER_PEARL, 40); add("end", Items.CHORUS_FRUIT, 12); add("end", Items.END_STONE, 4);
        add("end", Items.END_STONE_BRICKS, 6); add("end", Items.PURPUR_BLOCK, 8); add("end", Items.DRAGON_BREATH, 500);
        add("end", Items.END_ROD, 15); add("end", Items.ENDER_CHEST, 120); add("end", Items.END_CRYSTAL, 150);
        add("end", Items.ELYTRA, 6000);
        // ----- Food -----
        add("food", Items.GOLDEN_CARROT, 20); add("food", Items.BREAD, 5); add("food", Items.COOKED_BEEF, 6);
        add("food", Items.COOKED_PORKCHOP, 6); add("food", Items.COOKED_CHICKEN, 5); add("food", Items.COOKED_MUTTON, 5);
        add("food", Items.COOKED_SALMON, 5); add("food", Items.GOLDEN_APPLE, 60); add("food", Items.APPLE, 3);
        add("food", Items.BAKED_POTATO, 3); add("food", Items.CAKE, 30); add("food", Items.PUMPKIN_PIE, 8);
        add("food", Items.COOKIE, 1); add("food", Items.HONEY_BOTTLE, 15); add("food", Items.MELON_SLICE, 1);
        add("food", Items.SWEET_BERRIES, 2); add("food", Items.GLOW_BERRIES, 3);
        buildBlocks();
        buildDrops();
        buildExtra();
    }

    // ----- Muc 1: TAT CA block de xay nha -----
    static void buildBlocks() {
        String[] skip = {"spawner", "vault", "trial", "beacon", "conduit", "shulker_box", "portal", "command", "jigsaw", "structure", "barrier",
            "light", "bedrock", "reinforced", "dragon", "_head", "skull", "spawn", "test", "debug", "farmland", "infested", "budding", "frogspawn",
            "sculk_sensor", "sculk_shrieker", "sculk_catalyst", "respawn", "lodestone", "bed", "banner", "end_gateway", "knowledge", "air"};
        List<Entry> l = new ArrayList<>();
        for (Item it : net.minecraft.registry.Registries.ITEM) {
            if (!(it instanceof net.minecraft.item.BlockItem)) continue;
            String id = net.minecraft.registry.Registries.ITEM.getId(it).getPath();
            boolean bad = false;
            for (String s : skip) if (id.contains(s)) { bad = true; break; }
            if (bad) continue;
            double u = Prices.unit(it);
            if (u <= 0 || u > 2000) continue;
            l.add(new Entry(it, Math.max(1, Math.round(u * Prices.BUY_RATE * 100.0) / 100.0)));
        }
        CATALOG.put("blocks", l);
    }


    // ----- Muc moi: Giap, Mau ren, Vu khi & cong cu, Redstone, TAT CA vat pham (ban moi thu) -----
    static double buyPrice(Item it) {
        return Math.max(1, Math.round(Prices.unit(it) * Prices.BUY_RATE * 100.0) / 100.0);
    }

    static void buildExtra() {
        String[] redstoneKeys = {"redstone", "piston", "repeater", "comparator", "observer", "dropper", "dispenser", "hopper", "lever",
            "button", "pressure_plate", "tripwire", "daylight", "target", "rail", "note_block", "tnt", "slime_block", "honey_block",
            "lightning_rod", "crafter", "jukebox", "detector"};
        List<Entry> armor = new ArrayList<>(), templates = new ArrayList<>(), tools = new ArrayList<>(),
            redstone = new ArrayList<>(), all = new ArrayList<>();
        for (Item it : net.minecraft.registry.Registries.ITEM) {
            String id = net.minecraft.registry.Registries.ITEM.getId(it).getPath();
            if (Prices.unit(it) <= 0) continue;
            if (id.contains("spawner") || id.contains("vault") || id.contains("command_block")) continue;
            Entry e = new Entry(it, buyPrice(it));
            all.add(e);
            if (id.endsWith("_helmet") || id.endsWith("_chestplate") || id.endsWith("_leggings") || id.endsWith("_boots")
                || id.endsWith("_horse_armor") || id.endsWith("_wolf_armor") || id.equals("elytra") || id.equals("shield")) armor.add(e);
            if (id.endsWith("_smithing_template")) templates.add(e);
            if (id.endsWith("_sword") || id.endsWith("_pickaxe") || id.endsWith("_axe") || id.endsWith("_shovel") || id.endsWith("_hoe")
                || id.equals("bow") || id.equals("crossbow") || id.equals("trident") || id.equals("mace") || id.equals("fishing_rod")
                || id.equals("shears") || id.equals("flint_and_steel")) tools.add(e);
            for (String k : redstoneKeys) if (id.contains(k)) { redstone.add(e); break; }
        }
        armor.sort(java.util.Comparator.comparingDouble(Entry::price));
        tools.sort(java.util.Comparator.comparingDouble(Entry::price));
        // ----- ENCHANTED: TAT CA giap / vu khi / cong cu x nhieu loai phu phep. Gia = enchUnit x BUY_RATE x he so loai. 1 click = mua 1 mon -----
        List<Entry> ench = new ArrayList<>();
        for (Item it : net.minecraft.registry.Registries.ITEM) {
            if (Prices.unit(it) <= 0 || !Enchants.fullable(it)) continue;
            for (String[] vr : Enchants.variants(it)) {
                double pr = Math.round(Prices.enchUnit(it) * Prices.BUY_RATE * Double.parseDouble(vr[1]) * 100.0) / 100.0;
                ench.add(new Entry(it, pr, true, null, vr[2]));
            }
        }
        ench.sort(java.util.Comparator.comparingDouble(Entry::price));
        CATALOG.put("ench", ench);
        CATALOG.put("armor", armor); CATALOG.put("templates", templates); CATALOG.put("tools", tools);
        CATALOG.put("redstone", redstone); CATALOG.put("all", all);
    }

    // ----- Muc 2: do roi tu mob + do farm -----
    static void buildDrops() {
        Item[] d = {Items.ROTTEN_FLESH, Items.BONE, Items.BONE_MEAL, Items.GUNPOWDER, Items.STRING, Items.SPIDER_EYE, Items.ARROW, Items.FEATHER,
            Items.LEATHER, Items.RABBIT_HIDE, Items.INK_SAC, Items.GLOW_INK_SAC, Items.SLIME_BALL, Items.ENDER_PEARL, Items.BLAZE_ROD,
            Items.BLAZE_POWDER, Items.GHAST_TEAR, Items.MAGMA_CREAM, Items.PHANTOM_MEMBRANE, Items.PRISMARINE_SHARD, Items.PRISMARINE_CRYSTALS,
            Items.NAUTILUS_SHELL, Items.BREEZE_ROD, Items.SHULKER_SHELL, Items.WITHER_SKELETON_SKULL, Items.NETHER_STAR, Items.EGG,
            Items.COBBLESTONE, Items.KELP, Items.DRIED_KELP, Items.DRIED_KELP_BLOCK, Items.SUGAR_CANE, Items.CACTUS, Items.BAMBOO,
            Items.WHEAT, Items.CARROT, Items.POTATO, Items.MELON_SLICE, Items.PUMPKIN, Items.SWEET_BERRIES, Items.COAL, Items.IRON_INGOT,
            Items.GOLD_NUGGET, Items.EXPERIENCE_BOTTLE, Items.COD, Items.SALMON, Items.PUFFERFISH, Items.TROPICAL_FISH, Items.COPPER_INGOT,
            Items.REDSTONE, Items.LAPIS_LAZULI, Items.QUARTZ, Items.GLOWSTONE_DUST, Items.AMETHYST_SHARD, Items.ECHO_SHARD};
        for (Item it : d) {
            double u = Prices.unit(it);
            if (u <= 0) continue;
            add("drops", it, Math.max(1, Math.round(u * Prices.BUY_RATE * 100.0) / 100.0));
        }
    }

    // ----- Muc: SACH PHU PHEP (moi loai 1 dong, theo nhom: giap / vu khi / cong cu / cung / chung) -----
    static boolean booksBuilt = false;
    static void buildBooks() {
        if (booksBuilt || DonutLike.SERVER == null) return;
        booksBuilt = true;
        var reg = DonutLike.SERVER.getRegistryManager().getOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT);
        List<Object[]> rows = new ArrayList<>();
        for (var entry : reg.streamEntries().toList()) {
            String id = entry.registryKey().getValue().getPath();
            int max = entry.value().getMaxLevel();
            int grp = bookGroup(id);
            double price = Math.max(300, 400.0 * max);
            switch (id) {
                case "mending" -> price = 3000;
                case "silk_touch" -> price = 1500;
                case "fortune" -> price = 1800;
                case "wind_burst", "density", "breach" -> price = 2000;
                case "swift_sneak" -> price = 2500;
                case "soul_speed" -> price = 1500;
                case "binding_curse", "vanishing_curse" -> price = 100;
                default -> { }
            }
            rows.add(new Object[]{grp, id, entry, max, price});
        }
        rows.sort((a, b) -> {
            int c = Integer.compare((Integer) a[0], (Integer) b[0]);
            return c != 0 ? c : ((String) a[1]).compareTo((String) b[1]);
        });
        List<Entry> l = new ArrayList<>();
        for (Object[] r : rows) {
            @SuppressWarnings("unchecked")
            var holder = (net.minecraft.registry.entry.RegistryEntry<net.minecraft.enchantment.Enchantment>) r[2];
            ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
            var b = new net.minecraft.component.type.ItemEnchantmentsComponent.Builder(net.minecraft.component.type.ItemEnchantmentsComponent.DEFAULT);
            b.add(holder, (Integer) r[3]);
            book.set(DataComponentTypes.STORED_ENCHANTMENTS, b.build());
            l.add(new Entry(Items.ENCHANTED_BOOK, (Double) r[4], true, book));
        }
        CATALOG.put("books", l);
    }

    static int bookGroup(String id) {
        if (id.contains("protection") || id.contains("thorns") || id.equals("respiration") || id.equals("aqua_affinity") || id.equals("depth_strider")
            || id.equals("frost_walker") || id.equals("soul_speed") || id.equals("feather_falling") || id.equals("swift_sneak")) return 0; // giap
        if (id.equals("sharpness") || id.equals("smite") || id.equals("bane_of_arthropods") || id.equals("knockback") || id.equals("fire_aspect")
            || id.equals("looting") || id.equals("sweeping_edge") || id.equals("density") || id.equals("breach") || id.equals("wind_burst")) return 1; // vu khi
        if (id.equals("efficiency") || id.equals("silk_touch") || id.equals("fortune")) return 2; // cong cu
        if (id.equals("power") || id.equals("punch") || id.equals("flame") || id.equals("infinity") || id.equals("multishot") || id.equals("quick_charge")
            || id.equals("piercing") || id.equals("loyalty") || id.equals("riptide") || id.equals("channeling") || id.equals("impaling")) return 3; // cung/nỏ/đinh ba
        if (id.equals("luck_of_the_sea") || id.equals("lure")) return 4; // cau ca
        return 5; // chung: unbreaking, mending, curses
    }

    // ===== helpers =====
    static ItemStack icon(Item it, String name, String... lore) {
        ItemStack s = new ItemStack(it);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        if (lore.length > 0) {
            List<Text> l = new ArrayList<>();
            for (String x : lore) l.add(Text.literal(x));
            s.set(DataComponentTypes.LORE, new LoreComponent(l));
        }
        return s;
    }

    static void fill(SimpleInventory inv) {
        for (int i = 0; i < inv.size(); i++) inv.setStack(i, icon(Items.GRAY_STAINED_GLASS_PANE, " "));
    }

    static void ting(ServerPlayerEntity p) {
        if (!Settings.on(p.getUuid(), "sound")) return;
        p.getEntityWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1f, 1f);
    }

    /** So o trong con lai trong tui (36 o chinh) cho item nay. */
    static int space(ServerPlayerEntity sp, Item it) {
        int free = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = sp.getInventory().getStack(i);
            if (st.isEmpty()) free += it.getMaxCount();
            else if (st.isOf(it) && st.getComponentChanges().isEmpty()) free += Math.max(0, st.getMaxCount() - st.getCount());
        }
        return free;
    }

    /** Cho cho item co component (vd: do trong /ah). */
    static int spaceFor(ServerPlayerEntity sp, ItemStack ref) {
        int free = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = sp.getInventory().getStack(i);
            if (st.isEmpty()) free += ref.getMaxCount();
            else if (ItemStack.areItemsAndComponentsEqual(st, ref)) free += Math.max(0, st.getMaxCount() - st.getCount());
        }
        return free;
    }

    static boolean canReceiveStack(ServerPlayerEntity sp, ItemStack ref) {
        if (Admin.on("shop_dropfull")) return true;
        if (spaceFor(sp, ref) >= ref.getCount()) return true;
        DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống rồi thử lại.");
        return false;
    }

    /** Neu tat "shop_dropfull" thi tui day khong cho mua; bat thi do roi xuong dat. */
    static boolean canReceive(ServerPlayerEntity sp, Item it, int amount) {
        if (Admin.on("shop_dropfull")) return true;
        if (space(sp, it) >= amount) return true;
        DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống rồi mua tiếp.");
        return false;
    }

    static void later(ServerPlayerEntity sp, Runnable r) { DonutLike.SERVER.execute(r); }

    // ===== 1) MENU CHINH =====
    public static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Main(id, inv, new SimpleInventory(36)), Text.literal("Shop")));
    }

    static class Main extends GenericContainerScreenHandler {
        Main(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X4, id, pinv, inv, 4);
            fill(inv);
            inv.setStack(10, icon(Items.BRICKS, "§6§lBlocks", "§7Tất cả block để xây nhà", "§eClick để mở"));
            inv.setStack(11, icon(Items.BONE, "§f§lMob & Farm", "§7Thịt thối, thuốc súng, pearl, cobble, kelp...", "§eClick để mở"));
            inv.setStack(12, icon(Items.NETHERITE_SWORD, "§c§lGear", "§7Trang bị PvP", "§eClick để mở"));
            inv.setStack(13, icon(Items.QUARTZ_BLOCK, "§6§lNether", "§7Nguyên liệu Địa ngục", "§eClick để mở"));
            inv.setStack(14, icon(Items.SHULKER_BOX, "§5§lEnd", "§7Vật phẩm cao cấp", "§eClick để mở"));
            inv.setStack(15, icon(Items.GOLDEN_CARROT, "§a§lFood", "§7Thức ăn", "§eClick để mở"));
            inv.setStack(16, icon(Items.ELYTRA, "§b§lEnchanted", "§7Đồ FULL phù phép (elytra, giáp, vũ khí...)", "§7Giá = giá /order / sell", "§e1 click là mua"));
            inv.setStack(19, icon(Items.ENCHANTED_BOOK, "§d§lSách phù phép", "§7Mỗi loại phù phép một dòng", "§eClick để mở"));
            inv.setStack(20, icon(Items.EMERALD, "§d§lShard Shop", "§7Đổi điểm Shard", "§eClick để mở"));
            inv.setStack(21, icon(Items.DIAMOND_CHESTPLATE, "§b§lGiáp", "§7Tất cả loại giáp (da, xích, sắt, vàng, kim cương, netherite, rùa...)", "§eClick để mở"));
            inv.setStack(22, icon(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, "§d§lMẫu rèn", "§7Smithing Template: nâng netherite + toàn bộ mẫu trang trí giáp", "§eClick để mở"));
            inv.setStack(23, icon(Items.DIAMOND_PICKAXE, "§e§lVũ khí & công cụ", "§7Kiếm, cúp, rìu, xẻng, cuốc, cung, nỏ...", "§eClick để mở"));
            inv.setStack(24, icon(Items.REDSTONE, "§c§lRedstone", "§7Piston, hopper, observer, ray...", "§eClick để mở"));
            inv.setStack(25, icon(Items.NETHER_STAR, "§6§lTẤT CẢ vật phẩm", "§7Mua mọi thứ có trong game", "§eClick để mở"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0) {
                switch (slot) {
                    case 10 -> later(sp, () -> Category.open(sp, "blocks", 0));
                    case 11 -> later(sp, () -> Category.open(sp, "drops", 0));
                    case 12 -> later(sp, () -> Category.open(sp, "gear", 0));
                    case 13 -> later(sp, () -> Category.open(sp, "nether", 0));
                    case 14 -> later(sp, () -> Category.open(sp, "end", 0));
                    case 15 -> later(sp, () -> Category.open(sp, "food", 0));
                    case 16 -> later(sp, () -> Category.open(sp, "ench", 0));
                    case 19 -> later(sp, () -> { buildBooks(); Category.open(sp, "books", 0); });
                    case 20 -> later(sp, () -> ShardShop.open(sp));
                    case 21 -> later(sp, () -> Category.open(sp, "armor", 0));
                    case 22 -> later(sp, () -> Category.open(sp, "templates", 0));
                    case 23 -> later(sp, () -> Category.open(sp, "tools", 0));
                    case 24 -> later(sp, () -> Category.open(sp, "redstone", 0));
                    case 25 -> later(sp, () -> Category.open(sp, "all", 0));
                    default -> { }
                }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== 2) MENU CON (54 o) =====
    static class Category extends GenericContainerScreenHandler {
        final String cat; final int page; final List<Entry> list;
        static final int PER = 45;

        static void open(ServerPlayerEntity p, String cat, int page) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> new Category(id, inv, new SimpleInventory(54), cat, page),
                Text.literal("Shop - " + CAT_TITLE.get(cat))));
        }

        Category(int id, PlayerInventory pinv, SimpleInventory inv, String cat, int page) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.cat = cat; this.page = page; this.list = CATALOG.getOrDefault(cat, List.of());
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER; i++) {
                int idx = page * PER + i;
                if (idx >= list.size()) break;
                Entry e = list.get(idx);
                ItemStack d = e.make(1);
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§7" + e.make(1).getName().getString() + (e.ench() ? " §b(Full phù phép)" : "")),
                    Text.literal("§eBuy Price: §a$" + Prices.money(e.price())),
                    Text.literal((e.ench() || e.item().getMaxCount() == 1) ? "§aClick: mua 1 ngay §7| §aChuột phải: chọn số lượng" : "§aClick để chọn số lượng"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            inv.setStack(49, icon(Items.ARROW, "§eQuay lại"));
            if (page > 0) inv.setStack(45, icon(Items.ARROW, "§e← Trang trước", "§7Chuột phải: -10 trang"));
            if ((page + 1) * PER < list.size()) inv.setStack(53, icon(Items.ARROW, "§eTrang sau →", "§7Chuột phải: +10 trang", "§7Trang " + (page + 1) + "/" + ((list.size() + PER - 1) / PER)));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && (button == 0 || button == 1) && slot >= 0 && slot < 54) {
                if (button == 1 && slot < PER && page * PER + slot < list.size()) {
                    Entry e2 = list.get(page * PER + slot);
                    later(sp, () -> Qty.open(sp, cat, page, e2, 1));
                    syncState(); return;
                }
                if (slot == 49) later(sp, () -> ShopHandler.open(sp));
                else if (slot == 45 && page > 0) { int pg = Math.max(0, page - (button == 1 ? 10 : 1)); later(sp, () -> open(sp, cat, pg)); }
                else if (slot == 53 && (page + 1) * PER < list.size()) { int pg = Math.min((list.size() - 1) / PER, page + (button == 1 ? 10 : 1)); later(sp, () -> open(sp, cat, pg)); }
                else if (slot < PER && page * PER + slot < list.size()) {
                    Entry e = list.get(page * PER + slot);
                    if (e.ench() || e.item().getMaxCount() == 1) buyOne(sp, e);  // giap / vu khi / do phu phep: 1 click la mua 1 mon
                    else later(sp, () -> Qty.open(sp, cat, page, e, 1));
                }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    /** Mua ngay 1 mon (elytra, giap, vu khi, sach phu phep...). */
    static void buyOne(ServerPlayerEntity sp, Entry e) {
        ItemStack st = e.make(1);
        if (!canReceiveStack(sp, st)) return;
        if (DonutLike.bal(sp.getUuid()) < e.price()) {
            DonutLike.msg(sp, "§cYou don't have enough money! (cần $" + Prices.money(e.price()) + ")");
            return;
        }
        DonutLike.add(sp.getUuid(), -e.price());
        sp.getInventory().offerOrDrop(st);
        ting(sp);
        DonutLike.msg(sp, "§aĐã mua " + e.make(1).getName().getString() + " - $" + Prices.money(e.price()));
    }

    // ===== 3) CHON SO LUONG (27 o) =====
    static class Qty extends GenericContainerScreenHandler {
        static final int MAX = 2304;
        final SimpleInventory inv; final String cat; final int page; final Entry e; int qty;

        static void open(ServerPlayerEntity p, String cat, int page, Entry e, int qty) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> new Qty(id, inv, new SimpleInventory(27), cat, page, e, qty),
                Text.literal("Chọn số lượng")));
        }

        Qty(int id, PlayerInventory pinv, SimpleInventory inv, String cat, int page, Entry e, int qty) {
            super(ScreenHandlerType.GENERIC_9X3, id, pinv, inv, 3);
            this.inv = inv; this.cat = cat; this.page = page; this.e = e; this.qty = qty;
            refresh();
        }

        void refresh() {
            fill(inv);
            inv.setStack(10, icon(Items.RED_WOOL, "§c-64"));
            inv.setStack(11, icon(Items.RED_WOOL, "§c-10"));
            inv.setStack(12, icon(Items.RED_WOOL, "§c-1"));
            ItemStack d = e.make(1);
            d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("§eQuantity: §f" + qty),
                Text.literal("§eTotal Cost: §a$" + Prices.money(e.price() * qty)))));
            inv.setStack(13, d);
            inv.setStack(14, icon(Items.LIME_WOOL, "§a+1"));
            inv.setStack(15, icon(Items.LIME_WOOL, "§a+10"));
            inv.setStack(16, icon(Items.LIME_WOOL, "§a+64"));
            inv.setStack(21, icon(Items.GREEN_WOOL, "§2§lXÁC NHẬN MUA", "§7Số lượng: " + qty, "§7Tổng: §a$" + Prices.money(e.price() * qty)));
            inv.setStack(25, icon(Items.BARRIER, "§c§lHỦY", "§7Quay lại menu trước"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0 && slot >= 0 && slot < 27) {
                switch (slot) {
                    case 10 -> qty -= 64;
                    case 11 -> qty -= 10;
                    case 12 -> qty -= 1;
                    case 14 -> qty += 1;
                    case 15 -> qty += 10;
                    case 16 -> qty += 64;
                    case 25 -> { later(sp, () -> Category.open(sp, cat, page)); syncState(); return; }
                    case 21 -> { buy(sp); syncState(); return; }
                    default -> { }
                }
                qty = Math.max(1, Math.min(e.ench() ? 36 : MAX, qty));
                refresh();
            }
            syncState();
        }

        void buy(ServerPlayerEntity sp) {
            double cost = e.price() * qty;
            if (!canReceive(sp, e.item(), qty)) return;
            if (DonutLike.bal(sp.getUuid()) < cost) {
                DonutLike.msg(sp, "§cYou don't have enough money! (cần $" + Prices.money(cost) + ")");
                return;
            }
            DonutLike.add(sp.getUuid(), -cost);
            int left = qty;
            while (left > 0) {
                int n = Math.min(e.item().getMaxCount(), left);
                sp.getInventory().offerOrDrop(e.make(n));
                left -= n;
            }
            ting(sp);
            DonutLike.msg(sp, "§aĐã mua " + qty + "x " + e.make(1).getName().getString() + " - $" + Prices.money(cost));
            // giu nguyen man hinh chon so luong de mua tiep (khong thoat ra man hinh chinh)
            refresh();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
