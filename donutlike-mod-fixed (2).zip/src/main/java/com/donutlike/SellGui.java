package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * /sellgui (cung la /sell): mo 1 ruong de bo do vao. Dong ruong (ESC hoac E) la BAN HET.
 * - Moi vat pham co 1 gia rieng (Prices). Do khong co gia / khong ban duoc se tra lai vao tui.
 * - Sell multiplier: ban cang nhieu mon thi he so cang cao, toi da x3. Xem bang /sellmulti.
 */
public class SellGui {

    static final double MAX_MULT = 3.0;
    static final int ITEM_SLOTS = 45; // 0..44 = cho bo do; 45..53 = thanh thong tin

    /** Bang sell multi theo TONG GIA TRI (gia goc) da ban: {moc tien, he so}. Muon doi moc thi sua o day. Toi da x3. */
    static final double[][] TIERS = {
        {0, 1.0}, {10e6, 1.1}, {50e6, 1.2}, {100e6, 1.3}, {1e9, 1.4},
        // tu x1.5 tro len la SIEU CAO (shop ban x1.5: multi >= 1.5 se co the "mua shop - ban sell" kiem tien, nen rat kho dat)
        {1e12, 1.5}, {5e12, 1.6}, {20e12, 1.7}, {50e12, 1.8}, {100e12, 2.0},
        {1e15, 2.25}, {10e15, 2.5}, {100e15, 2.75}, {1e18, 3.0}
    };

    // ===== he so =====
    static long sold(UUID id) {
        if (DonutLike.save.soldItems == null) DonutLike.save.soldItems = new java.util.HashMap<>();
        return DonutLike.save.soldItems.getOrDefault(id.toString(), 0L);
    }

    static double soldMoney(UUID id) {
        if (DonutLike.save.soldMoney == null) DonutLike.save.soldMoney = new java.util.HashMap<>();
        return DonutLike.save.soldMoney.getOrDefault(id.toString(), 0.0);
    }

    static double mult(UUID id) {
        double s = soldMoney(id), m = 1.0;
        for (double[] t : TIERS) if (s >= t[0]) m = t[1];
        return Math.min(MAX_MULT, m);
    }

    /** Moc tiep theo (null = da toi da). */
    static double[] nextTier(UUID id) {
        double s = soldMoney(id);
        for (double[] t : TIERS) if (s < t[0]) return t;
        return null;
    }

    /** Gia 1 stack khi ban (chua nhan he so). 0 = khong ban duoc. */
    static double priceOf(ItemStack s) {
        if (s == null || s.isEmpty()) return 0;
        if (s.get(DataComponentTypes.CUSTOM_DATA) != null) return 0;            // do dac biet (Amethyst, to sec, ve rank...)
        if (Prices.unit(s.getItem()) <= 0) return 0;
        return Prices.stack(s);
    }

    static ItemStack filler() { return ShopHandler.icon(Items.GRAY_STAINED_GLASS_PANE, " "); }

    static boolean isFiller(ItemStack s) {
        return s.isOf(Items.GRAY_STAINED_GLASS_PANE) && s.get(DataComponentTypes.CUSTOM_NAME) != null
            && " ".equals(s.get(DataComponentTypes.CUSTOM_NAME).getString());
    }

    static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54), pl.getUuid()),
            Text.literal("Sell - bỏ đồ vào, bấm cục vàng để bán")));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID owner;

        Gui(int id, PlayerInventory pinv, SimpleInventory inv, UUID owner) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.owner = owner;
            for (int i = 0; i < ITEM_SLOTS; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = ITEM_SLOTS; i < 54; i++) inv.setStack(i, filler());
            refresh();
        }

        double rawTotal() {
            double t = 0;
            for (int i = 0; i < ITEM_SLOTS; i++) t += priceOf(inv.getStack(i));
            return t;
        }

        void refresh() {
            double raw = rawTotal();
            double m = mult(owner);
            List<Text> lore = new ArrayList<>();
            lore.add(Text.literal("§7Giá gốc: §f$" + Prices.money(raw)));
            lore.add(Text.literal("§7Sell multi: §ex" + String.format("%.2f", m) + " §7(tối đa x" + (int) MAX_MULT + ")"));
            lore.add(Text.literal("§aSẽ nhận: §e$" + Prices.money(raw * m)));
            double[] nx = nextTier(owner);
            lore.add(Text.literal(nx == null ? "§aĐã đạt multi tối đa!" : "§7Mốc tiếp: §ex" + nx[1] + " §7khi đã bán §a$" + Prices.money(nx[0])));
            lore.add(Text.literal("§eClick cục vàng này để bán ngay"));
            ItemStack total = new ItemStack(Items.GOLD_INGOT);
            total.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§6§lTổng bán"));
            total.set(DataComponentTypes.LORE, new LoreComponent(lore));
            inv.setStack(49, total);
            inv.setStack(46, ShopHandler.icon(Items.PAPER, "§eMỗi vật phẩm một giá khác nhau",
                "§7Đồ không có giá sẽ được trả lại túi", "§7Bán càng nhiều, multi càng cao"));
        }

        @Override
        public void onSlotClick(int slotIndex, int button, SlotActionType type, PlayerEntity player) {
            if (slotIndex >= ITEM_SLOTS && slotIndex < 54) { // thanh thong tin: khong cham duoc; bam cuc vang (o 49) = BAN LUON
                if (slotIndex == 49 && player instanceof ServerPlayerEntity sp) sellNow(sp);
                syncState(); return;
            }
            super.onSlotClick(slotIndex, button, type, player);
            refresh();
            syncState();
        }

        @Override
        public ItemStack quickMove(PlayerEntity player, int slot) {
            ItemStack ret = ItemStack.EMPTY;
            Slot s = this.slots.get(slot);
            if (s != null && s.hasStack()) {
                ItemStack st = s.getStack();
                ret = st.copy();
                if (slot >= 54) {
                    if (!this.insertItem(st, 0, ITEM_SLOTS, false)) return ItemStack.EMPTY;
                } else {
                    if (!this.insertItem(st, 54, this.slots.size(), true)) return ItemStack.EMPTY;
                }
                if (st.isEmpty()) s.setStack(ItemStack.EMPTY); else s.markDirty();
            }
            return ret;
        }

        /** Ban het do dang trong o (45 o tren). Goi khi bam cuc vang HOAC khi dong GUI. */
        void sellNow(ServerPlayerEntity sp) {
            double raw = 0; long count = 0;
            for (int i = 0; i < ITEM_SLOTS; i++) {
                ItemStack s = inv.removeStack(i);
                if (s.isEmpty()) continue;
                double v = priceOf(s);
                if (v > 0) { raw += v; count += s.getCount(); }
                else sp.getInventory().offerOrDrop(s); // khong ban duoc -> tra lai
            }
            if (count > 0) {
                double m = mult(sp.getUuid());
                double pay = raw * m;
                DonutLike.add(sp.getUuid(), pay);
                sold(sp.getUuid()); soldMoney(sp.getUuid()); // khoi tao map neu null
                DonutLike.save.soldItems.merge(sp.getUuid().toString(), count, Long::sum);
                DonutLike.save.soldMoney.merge(sp.getUuid().toString(), raw, Double::sum);
                ShopHandler.ting(sp);
                DonutLike.msg(sp, "§a[Sell] Đã bán §f" + count + " §amón: §e+$" + Prices.money(pay)
                    + " §7(giá gốc $" + Prices.money(raw) + " × multi x" + String.format("%.2f", m) + ")"
                    + (mult(sp.getUuid()) > m ? " §d→ multi tăng lên x" + String.format("%.2f", mult(sp.getUuid())) : ""));
            } else {
                DonutLike.msg(sp, "§7Không có gì để bán.");
            }
            refresh();
        }

        @Override
        public void onClosed(PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp) {
                sellNow(sp);
                for (int i = ITEM_SLOTS; i < 54; i++) { // phong ho do bi keo tha vao thanh thong tin
                    ItemStack s = inv.removeStack(i);
                    if (!s.isEmpty() && !isFiller(s) && s.getItem() != Items.GOLD_INGOT && s.getItem() != Items.PAPER) sp.getInventory().offerOrDrop(s);
                }
            }
            super.onClosed(player);
        }
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("sellgui").requires(s -> Admin.on("shop")).executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
        d.register(literal("sellmulti").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            double sm = soldMoney(p.getUuid());
            double[] nx = nextTier(p.getUuid());
            StringBuilder sb = new StringBuilder("§6Sell multi: §ex" + String.format("%.2f", mult(p.getUuid())) + " §7(tối đa x" + (int) MAX_MULT + ")\n§7Đã bán (giá gốc): §a$" + Prices.money(sm) + "\n");
            sb.append(nx == null ? "§a- Đã đạt multi tối đa!" : "§7Mốc tiếp theo: §ex" + nx[1] + " §7khi đạt §a$" + Prices.money(nx[0]) + " §7(còn §a$" + Prices.money(nx[0] - sm) + "§7)");
            sb.append("\n§8Các mốc: ");
            for (double[] t : TIERS) if (t[0] > 0) sb.append("§7x").append(t[1]).append("§8=§f$").append(Prices.money(t[0])).append("§8 | ");
            DonutLike.msg(p, sb.toString());
            return 1;
        }));
    }
}
