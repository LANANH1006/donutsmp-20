package com.donutlike;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

/** Tao do FULL phu phep (elytra, giap, vu khi, cong cu...) cho /shop, /order, /ah. */
public class Enchants {

    /** Loai do: helmet, chest, legs, boots, sword, axe, pick, shovel, hoe, elytra, bow, crossbow, trident, mace, shield, hoac "" neu khong co. */
    static String kind(Item item) {
        String id = Registries.ITEM.getId(item).getPath();
        if (id.endsWith("_helmet")) return "helmet";
        if (id.endsWith("_chestplate")) return "chest";
        if (id.endsWith("_leggings")) return "legs";
        if (id.endsWith("_boots")) return "boots";
        if (id.endsWith("_sword")) return "sword";
        if (id.endsWith("_pickaxe")) return "pick";
        if (id.endsWith("_axe")) return "axe";
        if (id.endsWith("_shovel")) return "shovel";
        if (id.endsWith("_hoe")) return "hoe";
        if (id.endsWith("_spear")) return "spear";
        return switch (id) {
            case "elytra" -> "elytra";
            case "bow" -> "bow";
            case "crossbow" -> "crossbow";
            case "trident" -> "trident";
            case "mace" -> "mace";
            case "shield" -> "shield";
            default -> "";
        };
    }

    static boolean fullable(Item item) { return !kind(item).isEmpty(); }

    /** Item dat tien du de dang "full phu phep" (kim cuong / netherite / elytra / mace / trident...) */
    static boolean premiumGear(Item item) {
        return fullable(item) && Prices.unit(item) > 0; // moi giap/vu khi/cong cu deu co ban full phu phep (gia x3)
    }

    private static void add(ItemStack s, RegistryKey<Enchantment> key, int lvl) {
        var reg = DonutLike.SERVER.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        s.addEnchantment(reg.getOrThrow(key), lvl);
    }

    /** Tra ve 1 item da gan full phu phep. Neu server chua san sang -> item thuong. */
    static final java.util.Map<Item, ItemStack> FULL = new java.util.HashMap<>();
    static Object cacheOwner = null;

    /** Co cache (rat nhieu lan goi khi mo /ah /order) - tranh lag. */
    static ItemStack full(Item item) {
        if (cacheOwner != DonutLike.SERVER) { FULL.clear(); VCACHE.clear(); cacheOwner = DonutLike.SERVER; }
        ItemStack c = FULL.get(item);
        if (c != null) return c.copy();
        ItemStack s = build(item);
        if (DonutLike.SERVER != null && !kind(item).isEmpty()) FULL.put(item, s.copy());
        return s;
    }


    // ===== NHIEU LOAI PHU PHEP cho tung mon (dung cho /shop, /ah, /order) =====
    static final java.util.Map<Item, java.util.List<String[]>> VARIANTS = new java.util.HashMap<>();
    static final java.util.Map<String, ItemStack> VCACHE = new java.util.HashMap<>();

    private static String[] v(String name, String vf, String spec) { return new String[]{name, vf, spec}; }

    /** Cac loai phu phep cua mon: {ten, he so gia, "id:cap,id:cap"}. Gia /shop = enchUnit x BUY_RATE x he so. */
    static java.util.List<String[]> variants(Item item) {
        return VARIANTS.computeIfAbsent(item, Enchants::buildVariants);
    }

    private static java.util.List<String[]> buildVariants(Item item) {
        String k = kind(item);
        String u = "unbreaking:3,mending:1";
        java.util.List<String[]> l = new java.util.ArrayList<>();
        switch (k) {
            case "helmet" -> {
                String t = ",respiration:3,aqua_affinity:1," + u;
                l.add(v("Protection IV", "1.00", "protection:4" + t));
                l.add(v("Blast Protection IV", "1.05", "blast_protection:4" + t));
                l.add(v("Fire Protection IV", "1.05", "fire_protection:4" + t));
                l.add(v("Projectile Protection IV", "1.05", "projectile_protection:4" + t));
                l.add(v("Thorns III + Protection IV", "1.10", "protection:4,thorns:3" + t));
            }
            case "chest" -> {
                String t = "," + u;
                l.add(v("Protection IV", "1.00", "protection:4" + t));
                l.add(v("Blast Protection IV", "1.05", "blast_protection:4" + t));
                l.add(v("Fire Protection IV", "1.05", "fire_protection:4" + t));
                l.add(v("Projectile Protection IV", "1.05", "projectile_protection:4" + t));
                l.add(v("Thorns III + Protection IV", "1.10", "protection:4,thorns:3" + t));
            }
            case "legs" -> {
                String t = ",swift_sneak:3," + u;
                l.add(v("Protection IV", "1.00", "protection:4" + t));
                l.add(v("Blast Protection IV", "1.05", "blast_protection:4" + t));
                l.add(v("Fire Protection IV", "1.05", "fire_protection:4" + t));
                l.add(v("Projectile Protection IV", "1.05", "projectile_protection:4" + t));
                l.add(v("Thorns III + Protection IV", "1.10", "protection:4,thorns:3" + t));
            }
            case "boots" -> {
                String t = ",feather_falling:4," + u;
                l.add(v("Protection IV + Depth Strider III", "1.00", "protection:4,depth_strider:3" + t));
                l.add(v("Protection IV + Soul Speed III", "1.05", "protection:4,soul_speed:3" + t));
                l.add(v("Blast Protection IV + Depth Strider", "1.05", "blast_protection:4,depth_strider:3" + t));
                l.add(v("Fire Protection IV + Soul Speed", "1.05", "fire_protection:4,soul_speed:3" + t));
                l.add(v("Projectile Protection IV + Depth Strider", "1.05", "projectile_protection:4,depth_strider:3" + t));
            }
            case "sword" -> {
                l.add(v("Sharpness V + Looting III + Fire Aspect II", "1.00", "sharpness:5,looting:3,fire_aspect:2,sweeping_edge:3," + u));
                l.add(v("Smite V + Looting III", "1.05", "smite:5,looting:3,sweeping_edge:3," + u));
                l.add(v("Bane of Arthropods V + Looting III", "1.05", "bane_of_arthropods:5,looting:3,sweeping_edge:3," + u));
                l.add(v("Sharpness V + Knockback II + Fire Aspect II", "1.10", "sharpness:5,knockback:2,fire_aspect:2," + u));
            }
            case "axe" -> {
                l.add(v("Sharpness V + Efficiency V", "1.00", "sharpness:5,efficiency:5," + u));
                l.add(v("Smite V + Efficiency V", "1.05", "smite:5,efficiency:5," + u));
                l.add(v("Efficiency V + Silk Touch", "1.05", "efficiency:5,silk_touch:1," + u));
            }
            case "pick", "shovel", "hoe" -> {
                l.add(v("Efficiency V + Fortune III", "1.00", "efficiency:5,fortune:3," + u));
                l.add(v("Efficiency V + Silk Touch", "1.05", "efficiency:5,silk_touch:1," + u));
            }
            case "bow" -> {
                l.add(v("Power V + Punch II + Flame", "1.00", "power:5,punch:2,flame:1," + u));
                l.add(v("Power V + Infinity", "1.05", "power:5,infinity:1,punch:2,flame:1,unbreaking:3"));
            }
            case "crossbow" -> {
                l.add(v("Quick Charge III + Piercing IV", "1.00", "quick_charge:3,piercing:4," + u));
                l.add(v("Quick Charge III + Multishot", "1.05", "quick_charge:3,multishot:1," + u));
            }
            case "trident" -> {
                l.add(v("Loyalty III + Impaling V + Channeling", "1.00", "loyalty:3,impaling:5,channeling:1," + u));
                l.add(v("Riptide III + Impaling V", "1.05", "riptide:3,impaling:5,unbreaking:3"));
            }
            case "mace" -> {
                l.add(v("Density V + Fire Aspect II + Wind Burst III", "1.00", "density:5,fire_aspect:2,wind_burst:3," + u));
                l.add(v("Breach IV + Fire Aspect II + Wind Burst III", "1.05", "breach:4,fire_aspect:2,wind_burst:3," + u));
            }
            case "spear" -> {
                l.add(v("Sharpness V + Lunge III + Looting III", "1.00", "sharpness:5,fire_aspect:2,looting:3,lunge:3," + u));
                l.add(v("Smite V + Lunge III + Looting III", "1.05", "smite:5,looting:3,lunge:3," + u));
            }
            default -> { if (!k.isEmpty()) l.add(v("Unbreaking III + Mending", "1.00", u)); }
        }
        return l;
    }

    /** Tao mon voi 1 loai phu phep (spec = "id:cap,id:cap"). Co cache. */
    static ItemStack variant(Item item, String spec) {
        if (cacheOwner != DonutLike.SERVER) { FULL.clear(); VCACHE.clear(); cacheOwner = DonutLike.SERVER; }
        String key = Registries.ITEM.getId(item) + "|" + spec;
        ItemStack c = VCACHE.get(key);
        if (c != null) return c.copy();
        ItemStack s = new ItemStack(item);
        if (DonutLike.SERVER == null) return s;
        for (String p : spec.split(",")) {
            String[] a = p.split(":");
            addId(s, a[0], Integer.parseInt(a[1]));
        }
        VCACHE.put(key, s.copy());
        return s;
    }

    private static void addId(ItemStack s, String path, int lvl) {
        try {
            var reg = DonutLike.SERVER.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            s.addEnchantment(reg.getOrThrow(RegistryKey.of(RegistryKeys.ENCHANTMENT, net.minecraft.util.Identifier.ofVanilla(path))), lvl);
        } catch (Throwable ignored) { }
    }

    private static ItemStack build(Item item) {
        ItemStack s = new ItemStack(item);
        String k = kind(item);
        if (k.isEmpty() || DonutLike.SERVER == null) return s;
        try {
            add(s, Enchantments.UNBREAKING, 3);
            add(s, Enchantments.MENDING, 1);
            switch (k) {
                case "helmet" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.RESPIRATION, 3); add(s, Enchantments.AQUA_AFFINITY, 1); }
                case "chest" -> add(s, Enchantments.PROTECTION, 4);
                case "legs" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.SWIFT_SNEAK, 3); }
                case "boots" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.FEATHER_FALLING, 4); add(s, Enchantments.DEPTH_STRIDER, 3); }
                case "sword" -> { add(s, Enchantments.SHARPNESS, 5); add(s, Enchantments.LOOTING, 3); add(s, Enchantments.FIRE_ASPECT, 2); add(s, Enchantments.SWEEPING_EDGE, 3); }
                case "axe" -> { add(s, Enchantments.SHARPNESS, 5); add(s, Enchantments.EFFICIENCY, 5); }
                case "pick", "shovel", "hoe" -> { add(s, Enchantments.EFFICIENCY, 5); add(s, Enchantments.FORTUNE, 3); }
                case "bow" -> { add(s, Enchantments.POWER, 5); add(s, Enchantments.PUNCH, 2); add(s, Enchantments.FLAME, 1); }
                case "crossbow" -> { add(s, Enchantments.QUICK_CHARGE, 3); add(s, Enchantments.PIERCING, 4); }
                case "trident" -> { add(s, Enchantments.LOYALTY, 3); add(s, Enchantments.IMPALING, 5); add(s, Enchantments.CHANNELING, 1); }
                case "spear" -> { add(s, Enchantments.SHARPNESS, 5); add(s, Enchantments.FIRE_ASPECT, 2); add(s, Enchantments.LOOTING, 3); addId(s, "lunge", 3); }
                case "mace" -> { add(s, Enchantments.DENSITY, 5); add(s, Enchantments.FIRE_ASPECT, 2); add(s, Enchantments.WIND_BURST, 3); }
                default -> { } // elytra, shield: chi Unbreaking 3 + Mending
            }
        } catch (Throwable t) { t.printStackTrace(); }
        return s;
    }
}
