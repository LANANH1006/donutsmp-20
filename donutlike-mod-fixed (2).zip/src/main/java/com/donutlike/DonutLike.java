package com.donutlike;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class DonutLike implements ModInitializer {

    // ===== Cau hinh nhanh =====
    static final double START_MONEY = 1000;        // tien khoi dau
    static final int BASE_INTERVAL_SECONDS = 600;  // moi 10 phut tu sinh 1 can cu

    // ===== Du lieu =====
    static class Home { double x, y, z; String dim; }
    static class Save {
        Map<String, Double> bal = new HashMap<>();
        double[] spawn = null;
        Map<String, String> names = new HashMap<>();
        Map<String, Map<String, Home>> homes = new HashMap<>();
        Map<String, Integer> kills = new HashMap<>(), deaths = new HashMap<>(), shards = new HashMap<>(),
                duelWins = new HashMap<>(), duelLosses = new HashMap<>();
        Map<String, Long> playSecs = new HashMap<>(), lastDaily = new HashMap<>(), lastKit = new HashMap<>();
        Set<String> baseCells = new HashSet<>(); // o luoi can cu da xu ly
        Map<String, Boolean> toggles = new HashMap<>(); // bat/tat tinh nang (Admin)
        Map<String, Double> nums = new HashMap<>();      // thiet lap so (Admin)
        boolean masterOff = false;                        // tat toan bo mod
        List<Market.SavedListing> listings = new ArrayList<>(); // do dang ban tren /ah
        Map<String, Spawners.Data> spawners = new HashMap<>(); // spawner da gop/dat (Spawners.java)
        List<String> admins = new ArrayList<>();           // chu mod (/lananhadm)
        List<Market.SavedOrder> orders = new ArrayList<>();   // /order dang cho (luu file, kem do da giao chua lay)
        Map<String, Boolean> psettings = new HashMap<>();     // /settings cua tung nguoi: "uuid|khoa" -> bat/tat
        Map<String, Double> soldMoney = new HashMap<>();   // tong gia tri (gia goc) da ban qua /sellgui (tinh sellmulti theo moc tien)
        Map<String, Long> soldItems = new HashMap<>();     // so mon da ban qua /sellgui (tinh sellmulti)
    }
    static final Map<String, Double> PRICES = new LinkedHashMap<>();
    static final String[] NAMES = {"Alex_VN", "DonutKing", "xX_Miner_Xx", "Hana", "Bao123", "NoobMaster", "Lan_Anh", "Zephyr", "TanSMP", "Minh_PvP", "CrystalGod", "Linh"};
    static final Random R = new Random();
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static Save save = new Save();
    static Path file;
    static MinecraftServer SERVER;
    static long tick = 0;

    static {
        PRICES.put("diamond", 100.0); PRICES.put("emerald", 40.0); PRICES.put("iron_ingot", 10.0);
        PRICES.put("gold_ingot", 15.0); PRICES.put("netherite_ingot", 800.0); PRICES.put("coal", 3.0);
        PRICES.put("copper_ingot", 4.0); PRICES.put("redstone", 3.0); PRICES.put("lapis_lazuli", 4.0);
        PRICES.put("oak_log", 2.0); PRICES.put("cobblestone", 1.0); PRICES.put("bread", 3.0);
        PRICES.put("golden_apple", 60.0); PRICES.put("ender_pearl", 25.0); PRICES.put("blaze_rod", 15.0);
        PRICES.put("obsidian", 8.0); PRICES.put("arrow", 1.0); PRICES.put("cooked_beef", 4.0);
        PRICES.put("diamond_sword", 250.0); PRICES.put("iron_sword", 40.0); PRICES.put("elytra", 3000.0);
    }

    @Override
    public void onInitialize() {
        file = FabricLoader.getInstance().getConfigDir().resolve("donutlike.json");
        load();
        if (save.baseCells == null) save.baseCells = new HashSet<>();
        Duels.init();
        Market.init();
        Combat.init();
        Notes.init();
        AntiLag.init();
        Tools.init();
        Spawners.init();
        FakeMarket.init();
        AfkBots.init();

        ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            Duels.endAll(s);
            // order duoc luu file (Market.snapshot) nen khong can hoan tien
            doSave(); // /ah duoc luu xuong file, nguoi ban offline khong mat do
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            tick++;
            Duels.tick(s);
            Warps.tick(s);
            if (tick % 10 == 0) Tools.tick(s);
            FakeMarket.tick(s);
            AfkBots.tick(s);
            Spawners.tick(s);
            if (tick % 20 == 0) everySecond(s);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> {
            // /spawn
            dispatcher.register(CommandManager.literal("spawn").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                if (Duels.inDuel(p)) { msg(p, "§cKhông thể dùng lệnh này khi đang duel."); return 0; }
                if (Combat.tagged(p)) { msg(p, "§cKhông thể /spawn khi đang combat!"); return 0; }
                ServerWorld w = ctx.getSource().getServer().getOverworld();
                double x, y, z;
                if (save.spawn != null) { x = save.spawn[0]; y = save.spawn[1]; z = save.spawn[2]; }
                else {
                    BlockPos sp = w.getSpawnPoint().getPos();
                    x = sp.getX() + 0.5; z = sp.getZ() + 0.5;
                    y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, sp.getX(), sp.getZ());
                }
                p.teleport(w, x, y, z, Set.of(), p.getYaw(), p.getPitch(), true);
                msg(p, "§aĐã dịch chuyển về spawn!");
                return 1;
            }));

            // /setspawn (op)
            dispatcher.register(CommandManager.literal("setspawn").requires(Admin::isAdmin).executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                save.spawn = new double[]{p.getX(), p.getY(), p.getZ()};
                doSave();
                msg(p, "§aĐã đặt spawn tại vị trí hiện tại.");
                return 1;
            }));

            // /bal
            dispatcher.register(CommandManager.literal("bal").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                msg(p, "§eSố dư: §a$" + fmt(bal(p.getUuid())));
                return 1;
            }));

            // /pay <player> <amount>
            dispatcher.register(CommandManager.literal("pay")
                .then(CommandManager.argument("player", EntityArgumentType.player())
                .then(CommandManager.argument("amount", DoubleArgumentType.doubleArg(0.01)).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(ctx, "player");
                    double a = DoubleArgumentType.getDouble(ctx, "amount");
                    if (!Settings.on(t.getUuid(), "pay")) { msg(p, "§c" + t.getName().getString() + " đã tắt nhận tiền (/settings)."); return 0; }
                    if (bal(p.getUuid()) < a) { msg(p, "§cBạn không đủ tiền."); return 0; }
                    add(p.getUuid(), -a); add(t.getUuid(), a);
                    msg(p, "§aĐã chuyển $" + fmt(a) + " cho " + t.getName().getString());
                    msg(t, "§aBạn nhận được $" + fmt(a) + " từ " + p.getName().getString());
                    return 1;
                }))));

            Admin.register(dispatcher);
            Market.register(dispatcher, registryAccess);
            Combat.register(dispatcher);
            Notes.register(dispatcher);
            AntiLag.register(dispatcher);
            ExtraCommands.register(dispatcher);
            Hud.register(dispatcher);
            ShardShop.register(dispatcher);
            Warps.register(dispatcher);
            FakeMarket.register(dispatcher);
            SellGui.register(dispatcher);
            HomeGui.register(dispatcher);
            Duels.register(dispatcher);
            Settings.register(dispatcher);

            // /randombase [intact|raided] (op) - sinh 1 can cu gan ban
            dispatcher.register(CommandManager.literal("randombase").requires(src -> Admin.isAdmin(src) && Admin.on("bases"))
                .executes(ctx -> runRandomBase(ctx.getSource(), null))
                .then(CommandManager.literal("intact").executes(ctx -> runRandomBase(ctx.getSource(), false)))
                .then(CommandManager.literal("raided").executes(ctx -> runRandomBase(ctx.getSource(), true))));
        });
    }

    static int runRandomBase(net.minecraft.server.command.ServerCommandSource src, Boolean raided) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity p = src.getPlayerOrThrow();
        Bases.Result r = Bases.spawnNear(src.getServer().getOverworld(), p.getBlockPos(), 40, 80, raided);
        if (r == null) { msg(p, "§cKhông tìm được chỗ đặt căn cứ, thử lại."); return 0; }
        msg(p, "§6Căn cứ " + r.style() + (r.raided() ? " (đã bị raid)" : " (còn nguyên)") + " tại "
                + r.pos().getX() + " " + r.pos().getY() + " " + r.pos().getZ());
        return 1;
    }

    // ===== Vong lap moi giay =====
    static void everySecond(MinecraftServer s) {
        ExtraCommands.everySecond(s);
        if (Admin.on("sidebar")) Hud.everySecond(s);
        if (tick % 40 == 0 && Admin.on("bases")) Bases.scatterTick(s);
        Combat.everySecond(s);
        AntiLag.everySecond(s);

        // sinh can cu ngau nhien
        if (tick % (20L * BASE_INTERVAL_SECONDS) == 0 && Admin.on("bases")) {
            List<ServerPlayerEntity> ps = s.getPlayerManager().getPlayerList();
            if (!ps.isEmpty()) {
                ServerPlayerEntity p = ps.get(R.nextInt(ps.size()));
                if (spawnBaseNear(s.getOverworld(), p.getBlockPos(), 150, 400) != null)
                    for (ServerPlayerEntity q : ps) msg(q, "§6Một căn cứ mới vừa xuất hiện đâu đó trong thế giới...");
            }
        }

        if (tick % (20 * 300) == 0) doSave();
    }

    // ===== Can cu ngau nhien (xem Bases.java) =====
    static BlockPos spawnBaseNear(ServerWorld w, BlockPos origin, int minD, int maxD) {
        Bases.Result r = Bases.spawnNear(w, origin, minD, maxD, null);
        return r == null ? null : r.pos();
    }

    static void set(ServerWorld w, BlockPos p, Block b) { w.setBlockState(p, b.getDefaultState(), Block.NOTIFY_LISTENERS); }
    static void set(ServerWorld w, BlockPos p, net.minecraft.block.BlockState st) { w.setBlockState(p, st, Block.NOTIFY_LISTENERS); }

    // ===== Tien & tien ich =====
    public static double bal(UUID id) { return save.bal.getOrDefault(id.toString(), START_MONEY); }
    public static void add(UUID id, double a) { save.bal.put(id.toString(), bal(id) + a); }
    public static double value(Item i) { return Prices.unit(i); }
    public static String fmt(double d) { return Prices.money(d); }
    public static void msg(ServerPlayerEntity p, String s) { p.sendMessage(Text.literal(s), false); }

    /** Chay 1 lenh bang dispatcher (khong phu thuoc ten ham CommandManager giua cac ban MC). */
    static void runCmd(net.minecraft.server.command.ServerCommandSource src, String cmd) {
        try { SERVER.getCommandManager().getDispatcher().execute(cmd, src); } catch (Exception e) { e.printStackTrace(); }
    }

    static void load() {
        try { if (Files.exists(file)) { Save s = GSON.fromJson(Files.readString(file), Save.class); if (s != null) save = s; } }
        catch (Exception e) { e.printStackTrace(); }
    }
    static void doSave() {
        try { Market.snapshot(); } catch (Exception e) { e.printStackTrace(); }
        try { Files.writeString(file, GSON.toJson(save)); } catch (Exception e) { e.printStackTrace(); }
    }
}
