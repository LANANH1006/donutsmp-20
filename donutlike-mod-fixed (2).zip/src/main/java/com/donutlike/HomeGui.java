package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * /home -> GUI 5 giuong. Chua dat = giuong TRANG, da dat = giuong XANH NUOC BIEN.
 * Moi map (the gioi / chieu khong gian) co 5 home rieng.
 * Click giuong trang: dat home tai cho dung. Click giuong xanh: dich chuyen. Chuot phai giuong xanh: xoa.
 */
public class HomeGui {

    static final int SLOTS = 5;
    static final int[] POS = {11, 12, 13, 14, 15};

    static String dim(ServerPlayerEntity p) { return p.getEntityWorld().getRegistryKey().getValue().toString(); }
    static String key(String dim, int i) { return dim + "#" + (i + 1); }

    static Map<String, DonutLike.Home> homes(ServerPlayerEntity p) {
        return DonutLike.save.homes.computeIfAbsent(p.getUuid().toString(), k -> new HashMap<>());
    }

    static String mapName(String dim) {
        return switch (dim) {
            case "minecraft:overworld" -> "Overworld";
            case "minecraft:the_nether" -> "Nether";
            case "minecraft:the_end" -> "End";
            default -> dim;
        };
    }

    static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(27), p), Text.literal("Homes - " + mapName(dim(p)))));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final ServerPlayerEntity owner; final String dim;

        Gui(int id, PlayerInventory pinv, SimpleInventory inv, ServerPlayerEntity owner) {
            super(ScreenHandlerType.GENERIC_9X3, id, pinv, inv, 3);
            this.inv = inv; this.owner = owner; this.dim = dim(owner);
            refresh();
        }

        void refresh() {
            ShopHandler.fill(inv);
            Map<String, DonutLike.Home> hs = homes(owner);
            for (int i = 0; i < SLOTS; i++) {
                DonutLike.Home h = hs.get(key(dim, i));
                if (h == null) {
                    inv.setStack(POS[i], ShopHandler.icon(Items.WHITE_BED, "§f§lHome " + (i + 1) + " §7(chưa đặt)",
                        "§7Map: §f" + mapName(dim), "§aClick để đặt home tại vị trí hiện tại"));
                } else {
                    inv.setStack(POS[i], ShopHandler.icon(Items.BLUE_BED, "§9§lHome " + (i + 1),
                        "§7Map: §f" + mapName(dim), "§7Toạ độ: §f" + (int) h.x + " " + (int) h.y + " " + (int) h.z,
                        "§aClick để dịch chuyển", "§cChuột phải để xoá"));
                }
            }
            inv.setStack(22, ShopHandler.icon(Items.PAPER, "§eHome của map §f" + mapName(dim), "§7Mỗi map có 5 home riêng"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && slot >= 0 && slot < 27) {
                int i = -1;
                for (int k = 0; k < SLOTS; k++) if (POS[k] == slot) i = k;
                if (i >= 0) {
                    Map<String, DonutLike.Home> hs = homes(sp);
                    String k = key(dim, i);
                    DonutLike.Home h = hs.get(k);
                    if (h == null) {
                        if (!dim(sp).equals(dim)) { DonutLike.msg(sp, "§cBạn đã đổi map, mở lại /home."); }
                        else {
                            DonutLike.Home n = new DonutLike.Home();
                            n.x = sp.getX(); n.y = sp.getY(); n.z = sp.getZ(); n.dim = dim;
                            hs.put(k, n);
                            DonutLike.msg(sp, "§aĐã đặt Home " + (i + 1) + " (" + mapName(dim) + ").");
                            ShopHandler.ting(sp);
                        }
                    } else if (button == 1) {
                        hs.remove(k);
                        DonutLike.msg(sp, "§eĐã xoá Home " + (i + 1) + ".");
                    } else {
                        final int homeNo = i + 1;
                        DonutLike.SERVER.execute(() -> {
                            sp.closeHandledScreen();
                            if (ExtraCommands.blocked(sp)) return;
                            ServerWorld w = DonutLike.SERVER.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(h.dim)));
                            if (w == null) w = DonutLike.SERVER.getOverworld();
                            ExtraCommands.tp(sp, w, h.x, h.y, h.z);
                            DonutLike.msg(sp, "§aĐã về Home " + homeNo + ".");
                        });
                        syncState();
                        return;
                    }
                    refresh();
                }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("home").executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
    }
}
